# ddb-serverless
Example of Lambda deployment done using serverless, with DynamoDB creation.
